package edu.com.upc.projectbienestarcompany.projectbienestarcompany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectBienestarCompanyApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjectBienestarCompanyApplication.class, args);
    }

}
