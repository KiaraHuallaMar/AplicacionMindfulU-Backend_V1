package edu.com.upc.projectbienestarcompany.projectbienestarcompany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectBienestarCompanyApplicationTests {

    @Test
    void contextLoads() {
    }

}
